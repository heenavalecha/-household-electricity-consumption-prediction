# Household Electricity Consumption Prediction Using Data Mining

## Project overview
This mini project predicts the next hour's household electricity consumption using **Random Forest Regression**.

## Dataset
- **Name:** Individual Household Electric Power Consumption
- **Source:** UCI Machine Learning Repository
- **Link:** https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption
- The notebook downloads the dataset automatically when it is run.

## Methodology
1. Download and load the UCI dataset.
2. Clean missing electricity readings.
3. Convert minute-level active power readings into approximate hourly energy consumption (kWh).
4. Create time-based and historical lag features.
5. Split data chronologically into 80% training and 20% testing.
6. Train a Random Forest Regressor.
7. Evaluate using MAE, MSE, RMSE and R-squared.
8. Generate graphs for consumption patterns, actual vs predicted values, and feature importance.

## Files
- `electricity_prediction.ipynb` — complete executable Python notebook.
- `requirements.txt` — Python dependencies.
- `results/` — generated after running the notebook; contains plots and evaluation outputs.

## How to run
### Google Colab
1. Open https://colab.research.google.com/
2. Select **File → Upload notebook**.
3. Upload `electricity_prediction.ipynb`.
4. Run the cells from top to bottom.
5. The notebook downloads the dataset and generates the evaluation results and visualizations.

### Local Jupyter Notebook
Install dependencies:
```bash
pip install -r requirements.txt
```
Then open `electricity_prediction.ipynb` and run all cells.

## Evaluation
The notebook reports:
- MAE (Mean Absolute Error)
- MSE (Mean Squared Error)
- RMSE (Root Mean Squared Error)
- R-squared

Lower MAE/RMSE and a higher R-squared generally indicate better predictive performance.

## Important note
The dataset contains readings from one household in Sceaux, France. Results describe this dataset and should not automatically be generalized to all households. The notebook calculates actual scores when executed; no performance values are assumed in advance.

## Author
Heena Valecha
